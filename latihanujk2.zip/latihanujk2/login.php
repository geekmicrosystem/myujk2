<?php
session_start();
require "js/koneksi.php";

if (isset($_SESSION['username'])) {
  echo '<script>window.location.href="pendaftaran.php"</script>';
}

if (isset($_POST['submit'])) {
  $username = htmlspecialchars($_POST['username']);
  $password = htmlspecialchars($_POST['password']);

  $sql = "SELECT * FROM akun_pasien WHERE username='$username'";
  $akun = mysqli_fetch_assoc(mysqli_query($conn, $sql));

  if ($akun) {
    if (password_verify($password, $akun['password'])) {
      $_SESSION['username'] = "$username";

      echo '<script>window.location.href="pendaftaran.php"</script>';
    } else {
      $salah = true;
    }
  }
}
?>

<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
</head>

<body>
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container">
      <a class="navbar-brand" href="#">
        <img src="img/logo.png" width="" height="50" class="d-inline-block align-top" alt="">
      </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon">Sistem Pendaftaran Vaksinasi</span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <div class="navbar-nav" style="font-weight: bold;">
          <a href="#" class="nav-link active">Sistem Pendaftaran Vaksinasi</a>
        </div>
        <div class="navbar-nav ml-auto" style="font-weight: bold;">
          <a href="register.php" class="btn btn-success btn-block">Register</a>
        </div>
      </div>
    </div>
  </nav>

  <div class="container">
    <div class="row justify-content-center mt-5">
      <div class="col-md-4">
        <div class="card shadow mb-4">
          <div class="card-header bg-transparent mb-0">
            <h5 class="text-center">Please <span class="font-weight-bold text-primary">LOGIN</span></h5>
            <?php if (isset($salah)) : ?>
              <small id="salah" style="color: red;">Username atau Password Salah!</small>
            <?php endif ?>
          </div>
          <div class="card-body">
            <form action="" method="POST">
              <div class="form-group">
                <input type="text" name="username" class="form-control" placeholder="Username">
              </div>
              <div class="form-group">
                <input type="password" name="password" class="form-control" placeholder="Password">
              </div>
              <div class="form-group">
                <input type="submit" name="submit" value="Login" class="btn btn-primary btn-block">
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous"></script>
</body>

</html>
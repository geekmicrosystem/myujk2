<?php 
    $hostname = 'localhost';
    $username = 'root';
    $password = '';
    $db = 'db_pendaftaran';

    $conn = mysqli_connect($hostname, $username, $password, $db);
?>
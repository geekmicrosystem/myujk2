<?php 
    session_start();
    require "js/koneksi.php";

    if (!isset($_SESSION['username'])){
        echo '<script>window.location.href="login.php"</script>';
    } else {

        $sql = "SELECT * FROM pasien";
        $insert = mysqli_query($conn, $sql);

        if(isset($_POST['submit'])){

            $nama = $_POST['nama'];
            $tanggal_lahir = $_POST['tanggal_lahir'];
            $alamat = $_POST['alamat'];
            $hp = $_POST['hp'];
            $jenis_kelamin = $_POST['kelamin'];
            $usia = $_POST['usia'];

            if ($usia <= 16) {
                $usiadibawah = true;
            } else {

                $data = "INSERT INTO pasien VALUES (NULL, 
                '$nama',
                '$tanggal_lahir',
                '$alamat',
                '$hp',
                '$jenis_kelamin',
                '$usia' )";

                $daftar = mysqli_query($conn, $data);

                if ($daftar) {
                    echo '<script>alert("Pendaftaran pasien baru berhasil")</script>';
                } else {
                    echo '<script>alert("Pendaftaran pasien gagal!!!)</script>';
                }
            }
        }
    }


?>

<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">

</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="#">
                <img src="img/logo.png" width="" height="50" class="d-inline-block align-top" alt="">
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon">Sistem Pendaftaran Vaksinasi</span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <div class="navbar-nav" style="font-weight: bold;">
                    <a href="#" class="nav-link active">Sistem Pendaftaran Vaksinasi</a>
                </div>
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="pendaftaran.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="form-group mt-5">
            <h1>Home</h1>
        </div>
        <div class="form-group">
            <a href="rekap.php">Lihat Rekap Data Pendaftaran
            </a>
        </div>
    </div>
    <div class="container mt-5">
        <form action="" method="POST">
            <div class="form-group">
                <label for="">Nama Lengkap</label>
                <input type="text" name="nama" class="form-control" placeholder="Masukan nama lengkap....">
            </div>
            <div class="form-group">
                <label for="">Tgl Lahir</label>
                <input type="date" name="tanggal_lahir" class="form-control" placeholder="Masukan tanggal lahir....">
            </div>
            <div class="form-group">
                <label for="">Alamat</label>
                <input type="text" name="alamat" class="form-control" placeholder="Masukan alamat....">
            </div>
            <div class="form-group">
                <label for="">HP</label>
                <input type="text" name="hp" class="form-control" placeholder="Masukan hp....">
            </div>
            <div class="form-group">
                <label for="">Jenis Kelamin</label>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="kelamin" id="exampleRadios1" value="laki-laki" checked>
                    <label class="form-check-label" for="exampleRadios1">
                        Laki-laki
                    </label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="kelamin" id="exampleRadios2" value="perempuan">
                    <label class="form-check-label" for="exampleRadios2">
                        Perempuan
                    </label>
                </div>
            </div>
            <div class="form-group">
                <label for="">Usia</label>
                <?php if (isset($usiadibawah)) : ?>
                    <small style="color: red">Usia anda masih dibawah 17 tahun</small>
                <?php endif ?>
                <input type="text" name="usia" class="form-control" placeholder="Masukan usia....">
            </div>
            <button name="submit" type="submit" class="btn btn-primary mb-5">Daftar</button>
        </form>
    </div>

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous"></script>

</body>

</html>